package testProjectPackage;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class StyleLabsExerciseTestNGClass {
	
	//Declaring driver
	WebDriver driver;
	
	//Method to be executed before test
	@BeforeTest
	public void LaunchApp()
	{
		//chrome exe path
		String exePath = "C:\\Jars\\chromedriver246\\chromedriver.exe";
		
		//setting property for chrome driver
		System.setProperty("webdriver.chrome.driver", exePath);
		
		//including chrome settings for loading chrome extensions
		ChromeOptions options=new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		//driver object
		driver = new ChromeDriver(options);
		
		//maximizing browser
		driver.manage().window().maximize();
		
		//providing maximum timout for every step 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	//DataProvider for providing data for exercise 1
	//in case exercise 1 needs to expand for some other search city- simply add in the object list
	@DataProvider(name="SearchProvider")
    public Object[][] getDataFromDataprovider(){
    return new Object[][] 
    	{
            { "Bahamas", "" },
            { "Amsterdam", "" }
        };
    }
	
	
	//Exercise 1 - Searching different cities in google
	@Test(dataProvider="SearchProvider")
    public void exercise1(String city1,String id1) throws IOException {
		
		//String url 
		String URL="http://www.google.com/";
		
		//navigating to the url
		driver.get(URL);
		
		//Fetching property of search input text box from page class - clearing the input text box and entering the city name
	    PageClass.SearchInputGoogle(driver).clear();
		PageClass.SearchInputGoogle(driver).sendKeys(city1 + "\n");
		
		//fetching list of search results 
		List<WebElement> findElementsLinks=PageClass.SearchResults(driver);
		
		//fetching result size
		int LinkLength=0;
		LinkLength=findElementsLinks.size();
		
		//printing result for test case if result has been greater than 0 or not
		if(LinkLength>0)
		{
			System.out.println("Exercise 1 TC - Passed--Number of search result links = " + LinkLength);
		}
		else
		{
			System.out.println("Exercise 1 TC - Failed--No search links are present");
	    }
		
		//taking screenshot of the result page
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		//saving the screenshot on C->Workspace->TestProject->Screenshots
		FileUtils.copyFile(scrFile, new File("C:\\Workspace\\TestProject\\Screenshots\\screenshot" + city1 + ".png"));
	}
	
	//Exercise 2 - Expedia - Searching cities and navigating to result page
	@Test
	public void exercise2() throws IOException, InterruptedException {
		
		//url for expedia and navigating to the url
		String URL="http://www.expedia.com/";
		driver.get(URL);
		
		//clicking on flight hotel 
		ExpediaPage.ClickFLightHotel(driver);
		
		//entering start city - Function and page objects are present in ExpediaPage class
		ExpediaPage.EnterStartCity(driver, "BRU");
		
		//entering destination city - Function and page objects are present in ExpediaPage class
		ExpediaPage.EnterDestinationCity(driver, "NYC");
		
		//entering start date - Function and page objects are present in ExpediaPage class
		ExpediaPage.EnterStartDate(driver, "06/27/2019");
		
		//entering return date - Function and page objects are present in ExpediaPage class
		ExpediaPage.EnterEndDate(driver, "07/10/2019");
		
		//entering travelers - 1adult 1child-3 year old
		ExpediaPage.EnterTravelerDetails(driver, "1", "1","3");
		
		//clicking on search button
		ExpediaPage.SearchButton(driver).click();
		
		//waiting for search results to be displayed
		Boolean bCheck=false;
		bCheck=ExpediaPage.CheckResultDisplayed(driver);
		
		//entering result-pass/fail whether result is diaplyed or not
		if (bCheck)
		{
			System.out.println("Exercise 2 TC Passed- Search Result Displayed");
		}
		else
		{
			System.out.println("Exercise 2 TC Failed- Search Result Displayed");
		}
	}
	
	@Test()
	public void exercise3() throws InterruptedException {
		
		 // Specify the base URL to the RESTful web service
		 RestAssured.baseURI = "https://api.openweather.org";
		 
		 // Get the RequestSpecification of the request that you want to sent
		 // to the server. The server is specified by the BaseURI that we have
		 // specified in the above step.
		 RequestSpecification httpRequest = RestAssured.given();
		 
		 // Make a request to the server by specifying the method Type and the method URL.
		 // This will return the Response from the server. Store the response in a variable.
		 Response response = httpRequest.request(Method.GET,"/data/2.5/weather?q=NY,usa&APPID=cde624619892c662365bfa0be2cd3a73");
		 
		 // Now let us print the body of the message to see what response
		 // we have recieved from the server
		 String responseBody = response.getBody().asString();
		 System.out.println("Response Body is =>  " + responseBody);
		 Thread.sleep(5000);		 
	}
	
	
	@AfterTest
	public void EndTest()
	{
		driver.quit();
	}
}
