package testProjectPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExpediaPage {
	private static WebElement element =null;
	
	//Flight and Hotel element
	public static WebElement FlightHotel(WebDriver driver){
		element = driver.findElement(By.id("fh-fh-hp-package"));
		return element;
	}
	
	//Start city element
	public static WebElement StartCity(WebDriver driver){
		element = driver.findElement(By.id("package-origin-hp-package"));
		return element;
	}
	
	//destination City element
	public static WebElement DestinationCity(WebDriver driver){
		element = driver.findElement(By.id("package-destination-hp-package"));
		return element;
	}
	
	//start date element
	public static WebElement StartDate(WebDriver driver){
		element = driver.findElement(By.id("package-departing-hp-package"));
		return element;
	}
	
	//return date element
	public static WebElement ReturnDate(WebDriver driver){
		element = driver.findElement(By.id("package-returning-hp-package"));
		return element;
	}
	
	//search button element
	public static WebElement SearchButton(WebDriver driver){
		element = driver.findElement(By.id("search-button-hp-package"));
		return element;
	}
	
	//search result element
	public static WebElement SearchResult(WebDriver driver){
		element = driver.findElement(By.id("bcol"));
		return element;
	}
	
	//Method to click on flight + hotel
	public static void ClickFLightHotel(WebDriver driver){
		String FlightHotelEnabled;
		//Check whether flight hotel is enabaled
		FlightHotelEnabled=ExpediaPage.FlightHotel(driver).getAttribute("checked");
		//if not enabled then click on flight and hotel
		if(!FlightHotelEnabled.equalsIgnoreCase("true"))
		{	
			ExpediaPage.FlightHotel(driver).click();
		}
	}
	
	//Method to enter start city
	public static void EnterStartCity(WebDriver driver, String startCity){
		ExpediaPage.StartCity(driver).clear();
		ExpediaPage.StartCity(driver).click();
		ExpediaPage.StartCity(driver).sendKeys(startCity);
	}
	
	//Method to enter destination city
	public static void EnterDestinationCity(WebDriver driver, String destinationCity){
		ExpediaPage.DestinationCity(driver).clear();
		ExpediaPage.DestinationCity(driver).click();
		ExpediaPage.DestinationCity(driver).sendKeys(destinationCity);
	}
	
	//method to enter start date
	public static void EnterStartDate(WebDriver driver, String startDate){
		ExpediaPage.StartDate(driver).clear();
		ExpediaPage.StartDate(driver).click();
		ExpediaPage.StartDate(driver).sendKeys(Keys.CONTROL + "a");
		ExpediaPage.StartDate(driver).sendKeys(Keys.BACK_SPACE);
		ExpediaPage.StartDate(driver).sendKeys(startDate);
	}
	
	//Method to enter return date
	public static void EnterEndDate(WebDriver driver, String endDate){
		ExpediaPage.ReturnDate(driver).clear();
		ExpediaPage.ReturnDate(driver).click();
		ExpediaPage.ReturnDate(driver).sendKeys(Keys.CONTROL + "a");
		ExpediaPage.ReturnDate(driver).sendKeys(Keys.BACK_SPACE);
		ExpediaPage.ReturnDate(driver).sendKeys(endDate);
	}
	
	//Method to check if search results are displayed
	public static boolean CheckResultDisplayed(WebDriver driver) throws InterruptedException{
		Boolean bCheck=false;
		//loooping till search element is displayed-total 1 min wait
		for(int i=0;i<=30;i++)
		{
			bCheck= ExpediaPage.SearchResult(driver).isDisplayed();
			if (bCheck)
			{
				break;
			}
			else
			{
				//waiting for 2 sec if search result is not displayed
				Thread.sleep(2000);
				bCheck=false;
			}
				 
		}
		return bCheck;
	}
	
	//Method to enter traveller details
	//todo- enter elements properties in methods and place regular expressions in xpath
	public static void EnterTravelerDetails(WebDriver driver, String numberOfAdultsTobeEnetered, String numberOfChildToBeEntered,String ChildAge) throws InterruptedException{
		
		//clicking on number of travellers input
		driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']//button[contains(@class,'trigger-utility')]")).click();
		String numberOfAdults,numberOfChild;
		
		//fetching number of adults already enetered
		numberOfAdults=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[2]/div[3]/span")).getText();
		
		//increasing number of adults to the required value
		if (Integer.parseInt(numberOfAdults)<Integer.parseInt(numberOfAdultsTobeEnetered))
		{
			while(!numberOfAdults.equalsIgnoreCase(numberOfAdultsTobeEnetered))
			{
				//clicking on plus sign
				driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[2]/div[4]/button")).click();
				numberOfAdults=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[2]/div[3]/span")).getText();
			}
		}
		
		//decreasing number of adults to the required value
		else
		{
			while(!numberOfAdults.equalsIgnoreCase(numberOfAdultsTobeEnetered))
			{
				//clicking on minus sign
				driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[2]/div[2]/button")).click();
				numberOfAdults=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[2]/div[3]/span")).getText();
			}
		}
			
		//fetching number of children
		numberOfChild=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[3]/div[1]/div[3]/span")).getText();
		
		//increasing number of children to the required value
		if (Integer.parseInt(numberOfChild)<Integer.parseInt(numberOfChildToBeEntered))
		{
			
			while(!numberOfChild.equalsIgnoreCase(numberOfChildToBeEntered))
			{
				//clicking on plus sign
				driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[3]/div[1]/div[4]/button")).click();
				numberOfChild=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[3]/div[1]/div[3]/span")).getText();
			}
		}
		
		//decreasing number of children to the required value
		else
		{
			while(!numberOfChild.equalsIgnoreCase(numberOfChildToBeEntered))
			{
				//clicking on minus sign
				driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[3]/div[1]/div[2]/button")).click();
				numberOfChild=driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']/div/ul/li/div/div/div[1]/div[3]/div[1]/div[3]/span")).getText();
			}
		}
		
		//entering age of child
		Select age=new Select(driver.findElement(By.xpath("//select[@data-gcw-storeable-name='gcw-child-age-1-1' and @class='gcw-storeable gcw-toggles-field-by-value gcw-child-age-select gcw-child-age-1-1-hc']")));
		age.selectByValue(ChildAge);
		driver.findElement(By.xpath("//*[@id='traveler-selector-hp-package']//button[contains(@class,'trigger-utility')]")).click();
		
	}	
}
