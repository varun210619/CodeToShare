package testProjectPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PageClass {
	private static WebElement element =null;

	public static WebElement SearchInputGoogle(WebDriver driver){
		element = driver.findElement(By.name("q"));
		return element;
	}
	
	public static List<WebElement> SearchResults(WebDriver driver){
		List<WebElement> findElementsLinks = driver.findElements(By.xpath("//*[@id='rso']//h3"));
		return findElementsLinks;
	}
}

